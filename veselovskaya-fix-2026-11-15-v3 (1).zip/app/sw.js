var C = "veselovskaya-web-v16";
var SHELL = ["./", "./index.html", "./manifest.webmanifest", "./favicon.svg"];
self.addEventListener("install", function(e){
  e.waitUntil(caches.open(C).then(function(c){ return c.addAll(SHELL); }).then(function(){ return self.skipWaiting(); }));
});
self.addEventListener("activate", function(e){
  e.waitUntil(caches.keys().then(function(ks){
    return Promise.all(ks.filter(function(k){ return k !== C; }).map(function(k){ return caches.delete(k); }));
  }).then(function(){ return self.clients.claim(); }));
});
function isDoc(req, url){
  return req.mode === "navigate" || (req.headers.get("accept") || "").indexOf("text/html") >= 0
    || /\.(html|webmanifest)$/i.test(url.pathname) || url.pathname === "/" || url.pathname.slice(-1) === "/";
}
self.addEventListener("fetch", function(e){
  var req = e.request, url;
  if(req.method !== "GET") return;
  try { url = new URL(req.url); } catch(err) { return; }
  if(url.origin !== location.origin) return;
  // страницы и манифест — сначала сеть: свежая версия важнее скорости
  if(isDoc(req, url)){
    e.respondWith(
      fetch(req).then(function(res){
        if(res && res.ok){ var cp = res.clone(); caches.open(C).then(function(c){ c.put(req, cp); }); }
        return res;
      }).catch(function(){
        return caches.match(req, { ignoreSearch: true }).then(function(hit){ return hit || caches.match("./index.html"); });
      })
    );
    return;
  }
  // остальное (иконки, скрипты) — из кэша, с обновлением в фоне
  e.respondWith(
    caches.match(req, { ignoreSearch: true }).then(function(hit){
      var net = fetch(req).then(function(res){
        if(res && res.ok){ var cp = res.clone(); caches.open(C).then(function(c){ c.put(req, cp); }); }
        return res;
      }).catch(function(){ return hit; });
      return hit || net;
    })
  );
});
